﻿namespace TelaStart
{
    public class AppCompatActivity
    {
    }
}